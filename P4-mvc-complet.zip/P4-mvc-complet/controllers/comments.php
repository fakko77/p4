<?php

function showsComAdmCRLT(){

    $tableau = completeCom($id);
    require('views/admin-header.php');
    require('views/admin-com.php');


}
function showsComSCRLT(){

    require('views/admin-header.php');
    require('views/admin-com-signaler.php');
   
}

function UsersCreatComCRLT(){
    if(isset($_POST["addcom"]))  
    {    
    $nom = $_POST['nom'];
    $com = $_POST['com'];
    creatCom($nom , $com , $id);
    }  
   

}
function admDeleteComCRLT(){

    
deleteCom($idcom);
header("location:index.php?url=admin-com.php&id=$id");  
}

function userComSCRLT(){

    signaler($idcom);
header("location:index.php?url=post.php&id=$id");  

}
?>