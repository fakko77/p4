<?php

function showsComAdmCRLT(){
    $id = $_GET['id'];
    $tableau = completeCom($id);
    
    $a= 0;
	$b = count($tableau) ; 
						
						//echo $b;
	
                       
    require('views/admin-header.php');
    require('views/admin-com.php');


}
function showsComSCRLT(){
   $tableau = showCommentsSignaled();
    //var_dump($tableau);
    $a= 0;
	$b = count($tableau) ; 
    require('views/admin-header.php');
    require('views/admin-com-signaler.php');
   
}

function UsersCreatComCRLT(){
    $id = $_GET['id'];
    if(isset($_POST["addcom"]))  
    {    
    $nom = $_POST['nom'];
    $com = $_POST['com'];
    creatCom($nom , $com , $id);
    }  
   

}
function admDeleteComCRLT(){

$id = $_GET['id'];
$idcom = $_GET['idcom'];
deleteCom($idcom);
header("location:index.php?url=admin-com.php&id=$id");  
}

function userComSCRLT(){
    $id = $_GET['id'];
    $idcom = $_GET['idcom'];
    signaler($idcom);
header("location:index.php?url=post.php&id=$id");  

}
?>