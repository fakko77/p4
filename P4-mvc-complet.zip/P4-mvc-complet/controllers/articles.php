<?php 

function homeCRLT(){
    require('views/utilisateur-head.php');
    articleView();
    require('views/utilisateur-footer.php');  
}

function addArticleCRLT(){

     
    if(isset($_POST["addArticle"]))  
    {    
    $titre = $_POST['titre'];
    $contenu = $_POST['area1'];
   /* $articles = new articles();
    $articles ->*/ creatArticle($titre , $contenu);
   
    }  
   require('views/admin-header.php');
    require('views/admin-panel.php');
}
function tableAdmCRLT(){

    require('views/admin-header.php');
    require('views/admin-edit.php');
    


}
function showsPageCRLT(){

    $article =  readArticlePage($id);
    require('views/utilisateur-post.php'); 
}

function admDeleteArticleCRLT(){

    deleteArticle($id);
    header("location:index.php?url=admin-edit.php");  
}

function admUpdateArticleCRLT(){

    $id = $_GET['id'];
   
   
    if(isset($_POST["update"]))  
          {  
                $titre = $_POST['titre'];
                $contenu = $_POST['area1'];
                echo $titre;
                echo $contenu;
                updateArticle($titre , $contenu , $id);
     
          }  
         
    require('views/admin-header.php');
    require('views/update.php');


}
?>