<?php 

function homeCRLT(){
    require('views/utilisateur-head.php');
   $tableau =  articleView();
   $a= 0;
   $b = count($tableau) ; 
  
   while($a < $b){
    $acc = $tableau[$a];

   echo"<div class='post-preview'>
   <a href='index.php?url=post.php&id=$acc[id]'>
     <h2 class='post-title'>
     $acc[titre]
     </h2>
     <h3 class='post-subtitle'>
     $acc[contenu]
     </h3>
   </a>

   <p class='post-meta'>Publier le $acc[date]</p>
 </div>
 <hr>";
 $a++;
   }
  
    require('views/utilisateur-footer.php');  
}

function addArticleCRLT(){

     
    if(isset($_POST["addArticle"]))  
    {    
    $titre = $_POST['titre'];
    $contenu = $_POST['area1'];
   /* $articles = new articles();
    $articles ->*/ creatArticle($titre , $contenu);
   
    }  
   require('views/admin-header.php');
    require('views/admin-panel.php');
}
function tableAdmCRLT(){
    $tableau = panel();
   
  
 
    require('views/admin-header.php');
    require('views/admin-edit.php');
    


}
function showsPageCRLT(){

    $id = $_GET['id'];
    $article =  readArticlePage($id);
    $id = $_GET['id'];
   
    $tableau = showComments($id);
    require('views/utilisateur-post.php'); 
}

function admDeleteArticleCRLT(){
    $id = $_GET['id'];
    deleteArticle($id);
    header("location:index.php?url=admin-edit.php");  
}

function admUpdateArticleCRLT(){

    $id = $_GET['id'];
    $tableau = readArticle($id); 
    
$a= 0;
$affiche;
$b = count($tableau) ; 
while($a < $b){
$tableau = $tableau[$a];
$affiche =  "<form method='post'>  
      <input style='display:none;' name='id' type='text' value='$tableau[id]' disabled />
                     <label>Titre</label>  
                     <input type='text' name='titre' class='form-control' value='$tableau[titre]' />  
                     <br />  
                     <label>Text</label>  

                      <textarea name='area1'   style='width: 100%;'>$tableau[contenu]</textarea>
                     <br />

                     <br />  
                     <input type='submit' name='update' class='btn btn-info' value='send' />  
                </form>  ";
	$a++;
}
   
    if(isset($_POST["update"]))  
          {  
                $titre = $_POST['titre'];
                $contenu = $_POST['area1'];
                echo $titre;
                echo $contenu;
                updateArticle($titre , $contenu , $id);
     
          }  
         
    require('views/admin-header.php');
    require('views/update.php');


}
?>