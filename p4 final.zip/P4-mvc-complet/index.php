<?php

require('model/function.php');
require('model/function-Com.php');
$url = '';
$id= '';
$idcom = '';
if(isset($_GET['url'])) {
    $url = $_GET['url'];
}
if(isset($_GET['id'])) {
    $id = $_GET['id'];
}

if(isset($_GET['idcom'])) {
    $idcom = $_GET['idcom'];
}

if($url == '') {
    require('vue/utilisateur-head.php');
    articleView();
    require('vue/utilisateur-footer.php');  
} elseif($url == 'log.php'){
    checklog();
    require('vue/log.php');


}
elseif($url == 'admin-panel.php'){

    $articles = getAllArticles();
    
     session_start();  
     if(isset($_SESSION["username"]))  
     {  
    
     }  
     else  
     {  
          header("location:log.php");  
     }  
    
    
     if(isset($_POST["addArticle"]))  
     {    
     $titre = $_POST['titre'];
     $contenu = $_POST['area1'];
     creatArticle($titre , $contenu);
    
     }  
    require('vue/admin-header.php');
     require('vue/admin-panel.php');
 

}
elseif($url == 'admin-edit.php'){
    $articles = getAllArticles();

 //login_success.php  
 session_start();  
 if(isset($_SESSION["username"]))  
 {  
   //echo '<h3>Login Success, Welcome - '.$_SESSION["username"].'</h3>';  

 }  
 else  
 {  
      header("location:log.php");  
 }  

require('vue/admin-header.php');
require('vue/admin-edit.php');


}elseif($url == 'admin-com.php' and !empty($id)){

    $articles = getAllArticles();
    
     //login_success.php  
    
    
     //echo $tableau[1];
     session_start();  
     $tableau = completeCom($id);
    
    
    
    
     if(isset($_SESSION["username"]))  
     {  
       //echo '<h3>Login Success, Welcome - '.$_SESSION["username"].'</h3>';  
    
     }  
     else  
     {  
          header("location:log.php");  
     }  
    
    
    require('vue/admin-header.php');
    require('vue/admin-com.php');
    
    


}elseif($url == 'admin-com-signaler.php'){
    session_start();  
    if(isset($_SESSION["username"]))  
    {  
      //echo '<h3>Login Success, Welcome - '.$_SESSION["username"].'</h3>';  
   
    }  
    else  
    {  
         header("location:log.php");  
    }  
   
    require('vue/admin-header.php');
    require('vue/admin-com-signaler.php');
   


} elseif($url == 'post.php' and !empty($id)){
    
    if(isset($_POST["addcom"]))  
    {    
    $nom = $_POST['nom'];
    $com = $_POST['com'];
    creatCom($nom , $com , $id);
    }  
   
    $article =  readArticlePage($id);
    require('vue/utilisateur-post.php'); 
}

elseif($url == 'deleteCom.php' and !empty($idcom) and !empty($id)){


deleteCom($idcom);
header("location:index.php?url=admin-com.php&id=$id");  

}
elseif($url == 'signaler.php' and !empty($idcom) and !empty($id)){
    signaler($idcom);
header("location:index.php?url=post.php&id=$id");  

}
elseif($url == 'delete.php' and !empty($id)){

    deleteArticle($id);
    header("location:index.php?url=admin-edit.php");  

}

elseif($url == 'update.php'){
    session_start();  
    if(isset($_SESSION["username"]))  
    {  
      //echo '<h3>Login Success, Welcome - '.$_SESSION["username"].'</h3>';  
   
    }  
    else  
    {  
         header("location:log.php");  
    }  
   $id = $_GET['id'];
   
   if(isset($_POST["update"]))  
         {  
               $titre = $_POST['titre'];
               $contenu = $_POST['area1'];
               echo $titre;
               echo $contenu;
               updateArticle($titre , $contenu , $id);
    
         }  
        
   require('vue/admin-header.php');
   require('vue/update.php');

}


/*

elseif(preg_match('#post.php-([0-9]+)#', $url, $params)) {
    $idArticle = $params[1];
    require 'article.php';
}*/ else {
    require '404.php';
}




?>


       
 



  