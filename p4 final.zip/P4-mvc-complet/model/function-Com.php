<?php 




/* Possibiliter de cree la class commentaire sans construre et cree mes function dans celle-ci */
class Commentaire
{
    private $_id;
    private $_nom;
    private $_com;
    private $_articleId;
    private $_signaler;

    function __construct($id, $nom, $com,$articleId,$signaler)
    {
        $this->_id = $id;
        $this->_nom = $nom;
        $this->_com = $com;
        $this->_articleId = $articleId;
        $this->_signaler = $signaler;
    }
   
    public function miseEnFormeCom($id){

        if($this->_signaler == "1"){
            echo "<span style ='background:rgba(193,66,66,0.5);'>";
        echo"<i class='fas fa-id-card'></i> : $this->_nom";
        echo"<br>";
        echo"<i class='far fa-comments'></i> : $this->_com";
        echo"<br>";
        echo"<a href='index.php?url=deleteCom.php&idcom=$this->_id&id=$this->_articleId' title='Supprimer commentaire'><i class='fas fa-trash-alt'></i></a>";
        echo"</span>";
        }else {

            echo "<span style =''>";
            echo"<i class='fas fa-id-card'></i> : $this->_nom";
            echo"<br>";
            echo"<i class='far fa-comments'></i> : $this->_com";
            echo"<br>";
            echo"<a href='index.php?url=deleteCom.php&idcom=$this->_id&id=$this->_articleId' title='Supprimer commentaire'><i class='fas fa-trash-alt'></i></a>";
            echo"</span>";
        }
        echo"<br>";
        echo"<br>";
 
        }



}

function creatCom($nom, $com, $id)
{
    try {
        $con = getDataBaseConnexion();
        $req = "INSERT INTO com (nom,com, articleId) values ('$nom','$com','$id')";
        $stmt = $con->query($req);
        header("location:index.php?url=post.php&id=$id");
    } catch (PDOException $e) {
        echo $e;
    }
}
    function deleteCom($idcom)
    {
        try {
            $con = getDataBaseConnexion();
            $req = "DELETE FROM com where id = '$idcom'";
            $stmt = $con->query($req);

                } catch (PDOException $e) {

            }

    }
    function signaler($idcom)
    {

        $con = getDataBaseConnexion();
        $req = "UPDATE com set signaler = '1' where id = '$idcom'"; 
        $stmt = $con->query($req);
    
    
    }
/****************** */
   function completeCom($id){

    $con = getDataBaseConnexion();
        $req = "SELECT * from com where articleId = '$id'"; 
        $stmt = $con->query($req);
    $tableau = array();
        while($donnees = $stmt->fetch()){
           
             $id = "$donnees[id]";
             $nom = "$donnees[nom]";
             $com = "$donnees[com]";
             $articleId = "$donnees[articleId]";
             $signaler = "$donnees[signaler]";  

            $Commentaire = new Commentaire($id,$nom,$com,$articleId,$signaler);
            array_push($tableau,  $Commentaire );
            
           }
        return $tableau;


   }


  /*  function afficherComAdmin($id)
    
    {
        $con = getDataBaseConnexion();
        $req = "SELECT * from com where articleId = '$id'"; 
        $stmt = $con->query($req);
    
        while($donnees = $stmt->fetch()){
    
            $a = "$donnees[signaler]";
           
                
                if($a == 1){
                    echo "<span style ='background:rgba(193,66,66,0.5);'>";
                echo"<i class='fas fa-id-card'></i> : $donnees[nom]";
                echo"<br>";
                echo"<i class='far fa-comments'></i> : $donnees[com]";
                echo"<br>";
                echo"<a href='deleteCom.php?idcom=$donnees[id]&id=$id' title='Supprimer commentaire'><i class='fas fa-trash-alt'></i></a>";
                echo"</span>";
                }else {
    
                    echo "<span style =''>";
                    echo"<i class='fas fa-id-card'></i> : $donnees[nom]";
                    echo"<br>";
                    echo"<i class='far fa-comments'></i> : $donnees[com]";
                    echo"<br>";
                    echo"<a href='deleteCom.php?idcom=$donnees[id]&id=$id' title='Supprimer commentaire'><i class='fas fa-trash-alt'></i></a>";
                    echo"</span>";
                }
                echo"<br>";
                echo"<br>";
         
         
        }
    
    }*/
    function comS()
    {
        $con = getDataBaseConnexion();
        $req = "SELECT * from com where signaler = '1'"; 
        $stmt = $con->query($req);
    
        while($donnees = $stmt->fetch()){
       
            echo"<i class='fas fa-id-card'></i> : $donnees[nom]";
            echo"<br>";
            echo"<i class='far fa-comments'></i> : $donnees[com]";
            echo"<br>";
            echo"<a href='index.php?url=admin-com.php&id=$donnees[articleId]' title='gerer'><i class='fas fa-cog'></i></a>";
        
            echo"<br>";
            echo"<br>";
        }
    
    
    }

    function afficherCom($id)
    {

        $con = getDataBaseConnexion();
        $req = "SELECT * from com where articleId = '$id'"; 
        $stmt = $con->query($req);
    
        while($donnees = $stmt->fetch()){
          echo"<i class='fas fa-id-card'></i> : $donnees[nom]";
          echo"<br>";
          echo"<i class='far fa-comments'></i> : $donnees[com]";
          echo"<br>";
          echo"<a href='index.php?url=signaler.php&idcom=$donnees[id]&id=$id' title='Signaler le commentaire'><i class='fas fa-exclamation-triangle'></i></a>";
          echo"<br>";
          echo"<br>";
    
         
        }

    }
    
    


?> 