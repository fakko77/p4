<?php
class Article{
    private $_titre;
    private $_contenu;
    private $_date;

    function __construct($titre, $contenu ,$date)
    {
        $this->_titre = $titre;
        $this->_contenu = $contenu;
        $this->_date = $date;
    }

    public function titre(){

       return $this->_titre;
    
    }
    public function contenu(){
        
        return $this->_contenu;
    }
    public function date(){

        return $this->_date;
    }
    public function miseEnForme(){

    echo"<h1> $this->_titre</h1>";
    echo"<br>";
    echo"<p>$this->_contenu</p>";
    echo"<br>";
  
    echo "<blockquote class='blockquote'>Derniere modification le  $this->_date </blockquote>";
    }


}


function getDataBaseConnexion(){

    try  
    {  $host = "localhost";  
        $username = "root";  
        $password = "";  
        $database = "p4";  
        $message = "";  
         $pdo = new PDO("mysql:host=$host; dbname=$database", $username, $password);  
         $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); 
         return $pdo;
} catch (PDOException $e) {
  echo 'Connexion échouée : ' . $e->getMessage();
  die();
}

}
function readArticlePage($id){
    $con = getDataBaseConnexion();
    $req = "SELECT * from articles where id = '$id'"; 
    $stmt = $con->query($req);

    while($donnees = $stmt->fetch()){
     $titre = "$donnees[titre]";
     $contenu = "$donnees[contenu]";
     $date = "$donnees[date]";
     $article = new Article($titre,$contenu,$date);
     return $article;
    }
}

function getAllArticles(){
$con = getDataBaseConnexion();
$req = 'SELECT * from articles'; 
$rows = $con->query($req);
return $rows;

}




function readArticle($id){
    $con = getDataBaseConnexion();
    $req = "SELECT * from articles where id = '$id'"; 
    $stmt = $con->query($req);

    while($donnees = $stmt->fetch()){
      echo  "<form method='post'>  
      <input style='display:none;' name='id' type='text' value='$donnees[id]' disabled />
                     <label>Titre</label>  
                     <input type='text' name='titre' class='form-control' value='$donnees[titre]' />  
                     <br />  
                     <label>Text</label>  

                      <textarea name='area1'   style='width: 100%;'>$donnees[contenu]</textarea>
                     <br />

                     <br />  
                     <input type='submit' name='update' class='btn btn-info' value='send' />  
                </form>  ";
      

     
     
    }
    
   
}

function creatArticle($titre , $contenu){
try {
    $con = getDataBaseConnexion();
    $req = "INSERT INTO articles (titre,contenu) values ('$titre','$contenu')"; 
    $stmt = $con->query($req);
    header("location:admin-panel.php"); 
} catch(PDOException $e){

}
    
}

        

function updateArticle($titre , $contenu,$id){
    try {
        $con = getDataBaseConnexion();
        $req = "UPDATE articles set titre = '$titre' , contenu = '$contenu' where id = '$id'"; 
        $stmt = $con->query($req);
        header("location:admin-edit.php");  
      
    } catch(PDOException $e){
    
    }
        
    }

function afficherTitre($id){
    try {
        $con = getDataBaseConnexion();
        $req = "SELECT titre from articles where id = '$id'"; 
        $stmt = $con->query($req);
        while($donnees = $stmt->fetch()){
            echo "<h2>$donnees[titre]</h2>";
        }
      
    } catch(PDOException $e){
    
    }


}
function deleteArticle($id){

    try {
        $con = getDataBaseConnexion();
        $req = "DELETE FROM articles where id = '$id'"; 
        $stmt = $con->query($req);
      
    } catch(PDOException $e){
    
    }
        
    }




function tableau(){
    try {
        $con = getDataBaseConnexion();
        $req = "SELECT * FROM articles ORDER BY date desc"; 
        $stmt = $con->query($req);

        while($donnees = $stmt->fetch()){
            echo "</tr>";
           
            // echo "<td> $donnees[RA] </td>";
             echo "<td width=15% > $donnees[titre] </td>";
             echo "<td width=50% > $donnees[contenu] </td>";
             echo "<td width=10%  > $donnees[date] </td>";
             
             $a = "$donnees[id]";
             echo "<td><a href='index.php?url=delete.php&id=$a'><button
                 type='button'>
                 supprimer
                </button></a></td>";
                echo "<td><a href='index.php?url=update.php&id=$a'><button
                type='button'>
                update
                </button></a></td>";
            echo"<td><a href='index.php?url=admin-com.php&id=$a'><i class='far fa-comments'></i></a></td>";
    
         
         
        }
      
    } catch(PDOException $e){
    
    }

}

function articleView(){


    try {
        $con = getDataBaseConnexion();
        $req = "SELECT * FROM articles ORDER BY date desc"; 
        $stmt = $con->query($req);

        while($donnees = $stmt->fetch()){
            $a = "$donnees[id]";
            echo"<div class='post-preview'>
            <a href='index.php?url=post.php&id=$a'>
              <h2 class='post-title'>
              $donnees[titre]
              </h2>
              <h3 class='post-subtitle'>
              $donnees[contenu]...
              </h3>
            </a>

            <p class='post-meta'>Publier le $donnees[date]</p>
          </div>
          <hr>";
         
        }
      
    } catch(PDOException $e){
    
    }

}
function checklog(){


    session_start();  
    $host = "localhost";  
    $username = "root";  
    $password = "";  
    $database = "p4";  
    $message = "";  
    try  
    {  
         $connect = new PDO("mysql:host=$host; dbname=$database", $username, $password);  
         $connect->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);  
    if(isset($_POST["login"]))  
          {  
               if(empty($_POST["username"]) || empty($_POST["password"]))  
               {  
                    $message = '<label>Veuillez completer les champs</label>';  
               }  
               else  
               {  
                    $query = "SELECT * FROM users WHERE username = :username AND password = :password";  
                    $statement = $connect->prepare($query);  
                    $statement->execute(  
                         array(  
                              'username'     =>     $_POST["username"],  
                              'password'     =>     $_POST["password"]  
                         )  
                    );  
                    $count = $statement->rowCount();  
                    if($count > 0)  
                    {  
                         $_SESSION["username"] = $_POST["username"];  
                         header("location:index.php?url=admin-panel.php");  
                    }  
                    else  
                    {  
                         $message = '<label>Mauvais identifiant ou mot de passe</label>';  
                    }  
               }  
          }  
     }  
     catch(PDOException $error)  
     {  
          $message = $error->getMessage();  
     }  
}


?>